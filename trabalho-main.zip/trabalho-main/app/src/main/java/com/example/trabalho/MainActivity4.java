package com.example.trabalho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {

    TextView resultado;
    String strNome;
    Float fltAltura, fltPeso, fltResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        resultado = (TextView) findViewById(R.id.txtView);
        Button btnVoltar4;
        btnVoltar4 = (Button) findViewById(R.id.btnVoltar4);


        btnVoltar4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltar();
            }
        });

        Intent intent = getIntent();
        strNome = intent.getStringExtra("nome");
        fltAltura = Float.parseFloat(intent.getStringExtra("altura"));
        fltPeso = Float.parseFloat(intent.getStringExtra("peso"));
        fltResult = fltPeso / (fltAltura * fltAltura);

        String strResult = "Olá " + strNome + "!";
        strResult = strResult + "\n" + "IMC = " + fltResult.toString();

        if(fltResult < 17) {
            strResult = strResult + "\n" + "Muito abaixo do peso";
        }
        else if(fltResult < 18.49){
            strResult = strResult + "\n" + "Abaixo do peso";
        }
        else if(fltResult < 24.99){
            strResult = strResult + "\n" + "Peso normal";
        }
        else if(fltResult < 29.99){
            strResult = strResult + "\n" + "Acima do peso";
        }
        else if(fltResult < 34.99){
            strResult = strResult + "\n" + "Obesidade I";
        }
        else if(fltResult < 39.99){
            strResult = strResult + "\n" + "Obesidade II (severa)";
        }
        else {
            strResult = strResult + "\n" + "Obesidade III (mórbida)";
        }

        resultado.setText(strResult);
    }
    public void voltar () {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}